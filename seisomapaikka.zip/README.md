# SEISOMAPAIKKA — Jumalauta

A real-time JML Engine demo. The furniture receives every privilege. You keep standing.

Serve this directory over HTTP, for example:

    python3 -m http.server 8080

Open http://localhost:8080 in a WebGL 2 browser with sound on. Click OTA NUMERO once. It requests fullscreen and runs for the complete 2:10 track. Reload to replay. Do not open index.html directly as a file.

Music: Rock Hybrid by Kevin MacLeod. Complete, unchanged.

"Rock Hybrid" by Kevin MacLeod (incompetech.com)
Licensed under Creative Commons Attribution 4.0 International
https://creativecommons.org/licenses/by/4.0/
Source: https://incompetech.com/music/royalty-free/index.html?Search=Search&isrc=USUAN1100094
Original audio: https://incompetech.com/music/royalty-free/mp3-royaltyfree/rock%20hybrid.mp3
ISRC: USUAN1100094
Music unchanged.


Concept, texts, graphics, model, choreography and code: Codex.
Engine: Jumalauta JML Engine, pinned at e58a1f6fc16e75003b2509a5471db27645191b41, unmodified.

See SOURCES.md for the ten productions studied and the review method. See VERIFICATION.md for playback checks.
